
# C++ Enterprise Integrations – 50 projektų rinkinys

Šiame rinkinyje – 50 **C++17** stub projektų integracijoms su **ServiceNow**, **Jira**, **Grafana**, **SolarWinds** ir kryžminėms sąsajoms. Visi projektai turi:

- `CMakeLists.txt` (portable build)
- Aiškiai komentuotą `main.cpp`
- `OAuth` ir `HTTP` klientų **stubus** (be tinklo)
- `config.json` su placeholder’iais ir **ENV** override
- Paprastą testą (`tests/test_main.cpp`)
- GitHub Actions **CI** workflow (`.github/workflows/ci-cd-pipeline.yml`)

> Realioje aplinkoje pakeiskite stubus į tikrus HTTP kvietimus ir OAuth srautą.
