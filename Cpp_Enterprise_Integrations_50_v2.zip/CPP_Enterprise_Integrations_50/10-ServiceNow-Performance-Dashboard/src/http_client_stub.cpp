
#include "http_client_stub.hpp"
// Implementacija yra header’yje (paprasta), čia laikome failą dėl aiškios struktūros.
